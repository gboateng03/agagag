import logo from "./logo.svg";
import "./App.css";
import BasicRouter from "./Router";

function App() {
  return <BasicRouter />;
}

export default App;
